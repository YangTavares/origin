void read_net (char *net_file, t_subblock_data *subblock_data_ptr);
