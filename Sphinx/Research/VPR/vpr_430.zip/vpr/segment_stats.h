void get_segment_usage_stats (int num_segment, t_segment_inf *segment_inf); 
